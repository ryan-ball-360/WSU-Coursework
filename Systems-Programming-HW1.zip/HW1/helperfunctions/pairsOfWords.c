#include "header.h"
#include "getWord.h"
#include "crc64.h"

//function that is only used as the compare function for qsort
int comparePairs(const void* a, const void* b) {
    const struct node* pairA = (const struct node*)a;
    const struct node* pairB = (const struct node*)b;
    return pairB->value - pairA->value;
}

int main(int argc, char *argv[])
{
    //step1: read file
    int pairsCount = argv[1]; //issue: implementation does not account for scenario where count is not specified
    struct hashTable wordPairTable;
    initializeHashTable(&wordPairTable, 100, 3);
    for(int i=2; i < argc; i++)
    {
        FILE *file = fopen(argv[i], "r"); //open file for reading
        if (file == NULL)
        {
            fprintf(stderr, "Error: opening file unsuccessful");
            continue;//if file cannot be opened, continue iterates through to try the next file, rather than terminating
        }

        //getNextword to get first pair of wordss
        char* prevWord = NULL;
        char* currWord = getNextWord(file);
        //strcat to combine the two words into a single string
        //since word pairs are sequential, order matters so word pairs can be stored as a single string

        while (currWord != NULL)
        {
            if(prevWord != NULL)
            {
                char* wordPair = (char*)malloc(strlen(prevWord) + strlen(currWord) + 2); // +2 for the space and null terminator
                if (wordPair == NULL)
                {
                    fprintf(stderr, "Error: memory allocation failde");
                    exit(1);
                }
                snprintf(wordPair, strlen(prevWord) + srtlen(currWord) + 2, "%s %s", prevWord, currWord);
            
                //since word pairs are sequential, order matters so word pairs can be stored as a single string
                //if search does not return null, then their is a key value pair and the value value is returned
                if (search(&wordPairTable, wordPair) != NULL)
                {
                    unsigned long long hash = crc64(wordPair);
                    int bucketIndex = (int)(hash % wordPairTable.capacity);
                    
                    //increment value of the word pair node by 1
                    wordPairTable.arr[bucketIndex]++; 
                }
                else
                {
                    insert(&wordPairTable, wordPair, 0);  //if search returns null, add the key to the hash table, with the count value initialized to 0
                }
                free(wordPair);
            }
            free(prevWord);
            prevWord = currWord;
            currWord = getNextWord(file);
            //to do: search hash table for matching pair of words
            //if pair is in table, add value to that node,
            //if pair is not in table, add new node using insert    
        }
    }
 
    int totalNodes = wordPairTable.numElements;
    struct node pairNodes[totalNodes]; //issue: variable is not a constant value, how do I make an array of this variables size?

    qsort(pairNodes, totalNodes, sizeof(struct node), comparePairs);

    //hash table and sorting outside the file loop because program outputs word pairs from all files combined, not each individual file

    for (int i = 0; i < pairsCount; i++)
    {
        printf("%10d %s\n", pairNodes->value, pairNodes->key);
    }


    free(wordPairTable); //free the memory for the hash table
    return 0;
}