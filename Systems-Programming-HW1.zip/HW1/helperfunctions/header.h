#include <stdio.h>

//Linked list node for hash table
struct node
{
    //key is string from pair of words
    char* key;
    int* value;
    struct node* next; 
};

struct hashTable
{
    int* numElements;
    int capacity;
    int maxCollisions; //Maximum number of collisions before resizing the hash table
    struct node** arr;
};

void setNode(struct node* node, char* key, char* value, int* count);
void initializeHashTable(struct hashTable* tb, int initialCapacity, int maxCollisions);
void insert(struct hashTable* tb, char* key, char* value);
void delete(struct hashTable* tb, char* key);
int* search(struct hashTable* tb, char* key);