#include "header.h"
#include "crc64.h"

void setNode(struct node* node, char* key, int* value)
{
    node->key = key;
    node->value = value;

    node->next = NULL;
    return;
}



void initializeHashTable(struct hashTable* tb, int initialCapacity, int maxCollisions)
{
    //starting capacity
    tb->capacity = initialCapacity;
    tb->numElements = 0;
    tb->maxCollisions = maxCollisions;
    tb->arr = (struct node**)malloc(sizeof(struct node*) *tb->capacity);
    for (int i = 0; i < tb->capacity; i++)
    {
        tb->arr[i] = NULL;
    }
    
    return;
}

//inserts a new node into the hashtable, resizing if maximum collisions are reached
void insert(struct hashTable* tb, char* key, int* value)
{
    unsigned long long hash = crc64(key);
    int bucketIndex = (int)(hash % tb->capacity);

    struct node* newNode = (struct node*)malloc(sizeof(struct node));//allocate memory for new node
    if (newNode == NULL)
    {
        fprintf(stderr, "Memory allocation failed");
        exit(1);
    }
    
    setNode(newNode, key, value);

    if (tb->arr[bucketIndex] == NULL)
    {
        tb->arr[bucketIndex]=newNode;
    }
    else
    {
        newNode->next = tb->arr[bucketIndex];
        tb->arr[bucketIndex] = newNode;

        //checking for collisions/resizing
        int numCollisions = 0;
        struct node* current = tb->arr[bucketIndex];
        while(current != NULL)
        {
            numCollisions++;
            current=current->next;
        }
        if(numCollisions >= tb->maxCollisions)
        {
            //resize the hash table by a factor of 3
            int newCapacity = tb->capacity * 3;
            struct hashTable newTable;
            initializeHashTable(&newTable, newCapacity, tb-> maxCollisions);

            //rehash and insert existing elements
            for (int i = 0; i < tb->capacity; i++)
            {
                current = tb->arr[i];
                while (current != NULL)
                {
                    insert(&newTable, current->key, current->value);
                    struct node* temp = current;
                    current = current->next;
                    //free memory from old node
                    free(temp);
                }
            }
            //free old array
            free(tb->arr);
            //update hash table
            *tb = newTable;
        }
    }
    tb->numElements++;
    return;
}

//delete function. was not used in my main function but I already wrote it
void delete (struct hashTable* tb, char* key)
{
    //is delete necessary?
    unsigned long long hash = crc64(key);
    int bucketIndex = (int)(hash % tb->capacity);

    struct node* prevNode = NULL;


    struct node* currNode = tb->arr[bucketIndex];

    while(currNode != NULL)
    {
        if(strcmp(key, currNode->key) == 0)
        {
            if(currNode == tb->arr[bucketIndex])
            {
                tb->arr[bucketIndex] = currNode->next;
            }
            else
            {
                prevNode->next = currNode->next;
            }
            free(currNode);
            break;
        }
        prevNode = currNode;
        currNode = currNode->next;
    }
    return;
}

int* search(struct hashTable* tb, char* key)
{
    unsigned long long hash = crc64(key);
    int bucketIndex = (int)(hash % tb->capacity);

    struct node* current = tb->arr[bucketIndex];
    while (current != NULL)
    {
        if (strcmp(current->key, key) == 0) {
            return current->value;
        }
        current = current->next;
    }
    fprintf(stderr, "Error: key not foundf");
    return NULL;
}