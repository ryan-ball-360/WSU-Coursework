#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

/***********************************************************************
name:RyanBall
	lineNum -- see if a word is in the online dictionary
description:	
	See CS 360 IO lecture for details.
***********************************************************************/

/* Includes and definitions */

/**********************************************************************
Search for given word in dictionary using file descriptor fd.
Return the line number the word was found on, negative of the last line searched
if not found, or the error number if an error occurs.
**********************************************************************/
int lineNum(char *dictionaryName, char *word, int dictWidth) {
	int fd;
	//open the file in read only
	fd = open(dictionaryName, O_RDONLY);
	// error handler for if the file cannot be opened. prints error and returns error code
	if (fd == -1)
	{
		printf("Error opening file: %d %s\n", errno, strerror(errno));
		return errno;
	}
	
	//truncate search word to dictionary dictWidth to allow for correct comparisons
	word[dictWidth] = '\0'; //null terminator placed where index matching the dictWidth, which for our purposes will allow the rest of the program to only read up to this null terminator, even if there were more characters

	//use lseek to determine file size
	off_t fileSize = lseek(fd, 0, SEEK_END); //SEEK_END moves file pointer to end of file
	//

	//if lseek can't find file size, print error and return error number
	if (fileSize == -1)
	{
		printf("Error finding file size: %d %s\n", errno, strerror(errno));
		close(fd);
		return errno;
	}
	//use file size and word dictWidth to calculate the total line number
	int lineCount = fileSize / dictWidth;

	//initialize binary search with left + right pointers
	int left = 0;
	int right = lineCount - 1;
	//buffer to hold file words
	char buffer[dictWidth + 1];
	buffer[dictWidth] = '\0';

	// binary search loop finding word in file
	while (left <= right)
	{
		//calculate middle line of this iteration's search range
		int mid = left + (right - left) / 2;
		//finds the file offset that corresponds to middle line. note: type off_t is used to describe file sizes
		off_t offset = mid * dictWidth;

		//set file offset to calculate offset to read the middle line word
		if (lseek(fd, offset, SEEK_SET) == -1)
		{
			//error to track lseek failures
			printf("Error seeking in file: %d %s\n", errno, strerror(errno)); //as per assignment instructions, error number and message are printed
			close(fd);
			return errno;
		}

		//reading middle line word into the buffer
		if(read(fd, buffer, dictWidth) != dictWidth)
		{
			//read fail error
			printf("Error reading from file: %d %s\n", errno, strerror(errno));
			close(fd);
			return errno;
		}

		//uses strcmp to compare the buffer word with the word from our input
		int cmp = strcmp(buffer, word);
		//if word matches return the line number
		if (cmp == 0)
		{
			close(fd);
			return mid;
		}
		// use comparison result to determine which half of the range will be used for the next iteration of the binary search
		if (cmp < 0)
		{
			left = mid + 1;
		}
		else
		{
			right = mid - 1;
		}
	}
	//if word isn't found, close file are return negative of last line number searched (left)
	close(fd);
	return -left;

}

int main() {
    // Change these values to test different cases
    char *dictionaryName = "tiny_9";
    char word[50] = "bear";
    int dictWidth = 16; // Adjust based on your dictionary's width

    int result = lineNum(dictionaryName, word, dictWidth);
    if (result >= 0) {
        printf("Word found at line: %d\n", result);
    } else {
        printf("Word not found. Last searched line: %d\n", -result);
    }

    return 0;
}